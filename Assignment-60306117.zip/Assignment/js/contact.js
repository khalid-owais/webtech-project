function validateForm() {
    let isValid = true;

    // Name Field Validation
    const nameElement = document.getElementById('name');
    const nameError = document.getElementById('name-error');
    if (nameElement.value.trim() === "") {
        nameElement.style.border = "2px solid red";
        nameError.textContent = "Please enter your name.";
        nameError.style.color = "red";
        isValid = false;
    } else {
        nameElement.style.border = "";
        nameError.textContent = "";
    }

    // Message Field Validation
    const messageElement = document.getElementById('message');
    const messageError = document.getElementById('message-error');
    if (messageElement.value.trim() === "") {
        messageElement.style.border = "2px solid red";
        messageError.textContent = "Please enter your message.";
        messageError.style.color = "red";
        isValid = false;
    } else {
        messageElement.style.border = "";
        messageError.textContent = "";
    }

    // Preferred Contact Method Validation
    const contactMethods = document.getElementsByName('contact-method');
    const methodError = document.getElementById('method-error');
    const isMethodSelected = Array.from(contactMethods).some(method => method.checked);
    if (!isMethodSelected) {
        methodError.textContent = "Please select a preferred contact method.";
        methodError.style.color = "red";
        isValid = false;
    } else {
        methodError.textContent = "";
    }

    // Email Field Validation
    const emailElement = document.getElementById('email');
    const emailError = document.getElementById('email-error');
    if (emailElement.value.trim() === "") {
        emailElement.style.border = "2px solid red";
        emailError.textContent = "Please enter your email.";
        emailError.style.color = "red";
        isValid = false;
    } else {
        emailElement.style.border = "";
        emailError.textContent = "";
    }

    return isValid; // Prevent form submission if any field is invalid
}
