function validateName() {
    const nameElement = document.getElementById('full-name');
    const errorElement = document.getElementById('name-error');
    let isValid = true;

    if (!nameElement.value.trim()) {
        nameElement.style.border = "2px solid red";
        errorElement.textContent = "Full Name is required.";
        errorElement.style.color = "red";
        isValid = false;
    } else {
        nameElement.style.border = "1px solid black";
        errorElement.textContent = "";
    }

    return isValid;
}

function validateUsername() {
    const usernameElement = document.getElementById('username');
    const errorElement = document.getElementById('username-error');
    let isValid = true;

    if (!usernameElement.value.trim()) {
        usernameElement.style.border = "2px solid red";
        errorElement.textContent = "Username is required.";
        errorElement.style.color = "red";
        isValid = false;
    } else {
        usernameElement.style.border = "1px solid black";
        errorElement.textContent = "";
    }

    return isValid;
}

function validatePassword() {
    const password = document.getElementById('password');
    const confirmPassword = document.getElementById('confirm-password');
    const passwordError = document.getElementById('password-error');
    const confirmPasswordError = document.getElementById('confirm-password-error');
    let isValid = true;

    if (!password.value.trim()) {
        password.style.border = "2px solid red";
        passwordError.textContent = "Password is required.";
        passwordError.style.color = "red";
        isValid = false;
    } else {
        password.style.border = "1px solid black";
        passwordError.textContent = "";
    }

    if (confirmPassword.value.trim() !== password.value.trim()) {
        confirmPassword.style.border = "2px solid red";
        confirmPasswordError.textContent = "Passwords do not match.";
        confirmPasswordError.style.color = "red";
        isValid = false;
    } else {
        confirmPassword.style.border = "1px solid black";
        confirmPasswordError.textContent = "";
    }

    return isValid;
}

function validateEmail() {
    const email = document.getElementById('email');
    const confirmEmail = document.getElementById('confirm-email');
    const emailError = document.getElementById('email-error');
    const confirmEmailError = document.getElementById('confirm-email-error');
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    let isValid = true;

    if (!emailPattern.test(email.value.trim())) {
        email.style.border = "2px solid red";
        emailError.textContent = "Enter a valid email address.";
        emailError.style.color = "red";
        isValid = false;
    } else {
        email.style.border = "1px solid black";
        emailError.textContent = "";
    }

    if (confirmEmail.value.trim() !== email.value.trim()) {
        confirmEmail.style.border = "2px solid red";
        confirmEmailError.textContent = "Emails do not match.";
        confirmEmailError.style.color = "red";
        isValid = false;
    } else {
        confirmEmail.style.border = "1px solid black";
        confirmEmailError.textContent = "";
    }

    return isValid;
}

function validatePhoneNumber() {
    const phone = document.getElementById('phone');
    const phoneError = document.getElementById('phone-error');
    const phoneRegex = /^\+974\d{8}$/;
    let isValid = true;

    if (!phone.value.trim()) {
        phone.style.border = "2px solid red";
        phoneError.textContent = "Phone number is required.";
        phoneError.style.color = "red";
        isValid = false;
    } else if (!phoneRegex.test(phone.value.trim())) {
        phone.style.border = "2px solid red";
        phoneError.textContent = "Phone number must start with +974 followed by 8 digits.";
        phoneError.style.color = "red";
        isValid = false;
    } else {
        phone.style.border = "1px solid black";
        phoneError.textContent = "";
    }

    return isValid;
}

function validateBuilding() {
    const building = document.getElementById('building');
    const errorElement = document.getElementById('building-error');
    let isValid = true;

    if (!building.value.trim()) {
        building.style.border = "2px solid red";
        errorElement.textContent = "Building number is required.";
        errorElement.style.color = "red";
        isValid = false;
    } else {
        building.style.border = "1px solid black";
        errorElement.textContent = "";
    }

    return isValid;
}

function validateStreet() {
    const street = document.getElementById('street');
    const errorElement = document.getElementById('street-error');
    let isValid = true;

    if (!street.value.trim()) {
        street.style.border = "2px solid red";
        errorElement.textContent = "Street name is required.";
        errorElement.style.color = "red";
        isValid = false;
    } else {
        street.style.border = "1px solid black";
        errorElement.textContent = "";
    }

    return isValid;
}

function validateForm() {
    const validations = [
        validateName(),
        validateUsername(),
        validatePassword(),
        validateEmail(),
        validatePhoneNumber(),
        validateBuilding(),
        validateStreet()
    ];

    // Ensure all validations pass
    const isFormValid = validations.every(Boolean);

    if (!isFormValid) {
        return false; // Prevent form submission
    }

    return true; // Allow form submission if all validations pass
}
